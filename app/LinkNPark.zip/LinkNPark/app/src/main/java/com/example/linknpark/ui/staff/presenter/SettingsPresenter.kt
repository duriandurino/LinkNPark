package com.example.linknpark.ui.staff.presenter

class SettingsPresenter {
}